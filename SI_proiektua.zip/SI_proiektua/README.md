# SI_proiektua
Egileak:
Leire Garcia, Aitor San José, Martin Amezola eta Kerman San Juan