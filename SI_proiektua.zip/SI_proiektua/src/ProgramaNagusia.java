import view.SudokuBista;

public class ProgramaNagusia {

	public static void main(String[] args) {
		/**
		 * Kaixo, ongi etorri <3
		 *
		 * Hasiera Panela egikaritzean erabiltzailearen izena sartu eta 1, 2 edo 3
		 * balioak SudokuBista agertzeko, beste zenbakiren bat sartzerakoan errore mezua
		 * agertuko da eta berriro saiatzeko eskaten zaio erabiltzaileari.
		 *
		 */
		SudokuBista.main(null);

	}

}
