public class RawTablero {
    private int[][] soluzioa;
    private int[][] bista;
    public RawTablero(){}

    public void setSoluzioa(int[][] s){
        this.soluzioa = s;
    }
    public void setBista(int[][] b){
        this.bista = b;
    }

    
}
