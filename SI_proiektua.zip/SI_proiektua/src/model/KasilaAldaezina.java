package model;

public class KasilaAldaezina extends Kasila {

	public KasilaAldaezina(int pErr, int pZut) {
		super(pErr, pZut);
	}

}
